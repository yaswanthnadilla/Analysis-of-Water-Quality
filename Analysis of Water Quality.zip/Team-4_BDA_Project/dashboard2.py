import random
import pandas as pd
from bokeh.driving import count
from bokeh.models import ColumnDataSource
from kafka import KafkaConsumer
from bokeh.plotting import curdoc, figure
from bokeh.models import DatetimeTickFormatter
from bokeh.models.widgets import Div
from bokeh.layouts import column,row
import ast
import time
import pytz
from datetime import datetime

tz = pytz.timezone('Asia/Calcutta')
UPDATE_INTERVAL = 1000
k = []
counts = []
ROLLOVER = 10 # Number of displayed data points
source = ColumnDataSource({"x": [], "y": [],"z":[]})
consumer = KafkaConsumer('CleanSensor', auto_offset_reset='earliest',bootstrap_servers=['localhost:9092'], consumer_timeout_ms=1000)
div = Div(
    text='',
    width=200,
    height=100
)
div.align = "center"
@count()
def update(x):
    for msg in consumer:
        msg_value=msg
        break
    values=ast.literal_eval(msg_value.value.decode("utf-8"))
    x=((values["TimeStamp"]["$date"])/1000.0)
    x=datetime.fromtimestamp(x, tz).isoformat()
    x=pd.to_datetime(x)
   
    print(x)

    div.text = "TimeStamp: "+str(x)
    y = values['WaterTemperature']
    pp = values['Turbidity']
    z = values['WaterStatus']
    
    k.append(z)
    gc = k.count('good for living')
    bc = k.count('bad for living')
    print(gc,bc)
    print(y)
    print(z)
    counts = [gc,bc]
    source.stream({"x": [x], "y": [y],"z":[pp]},ROLLOVER)

from bokeh.plotting import figure, show
q = figure(x_range=['good for living','bad for living'], height=350, title="Fruit Counts",
           toolbar_location=None, tools="")
q.vbar(x=['good for living','bad for living'], top=counts, width=0.9)
show(q)
doc = curdoc()
#doc.add_root(p)

doc.add_root(
    row(children=[div,q])
)
doc.add_periodic_callback(update, UPDATE_INTERVAL)
